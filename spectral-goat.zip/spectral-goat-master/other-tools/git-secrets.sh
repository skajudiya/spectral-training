git secrets --register-aws
git secrets --scan